# Final_LunaBectuchi

El sitio web que está maqueteado aquó corresponde a la materia producción digital II dictada por el profesor Guido Varela para la Universidad de Palermo. 


La página busca simular un portfolio para el fotografo Peruano Mario Testino. Para desarrollar la misma, utilizamos distintos los conocimientos que adquirimos a lo largo del cuatrimestre como: 


-Animaciones


-transiciones


-maqueteado con Bootstrap


Link a la página:
https://finallunabectuchi.netlify.app/index.html



Dentro de este repositorio se encuentran los siguientes archivos:


Cartpeta CSS con los archivos de estilo de la página.


Carpeta IMG con Las imágenes utilizadas para el desarrollo de la página, y a su vez, dentro de esta se encuentra también una carpeta donde están los screenshots de 
cada una de las secciones de la página en sus 3 resoluciones. También, dentro de esta carpeta, se encuentra el video justificativo del trabajo. 

Archivos html.

Carpeta de Asstes para el maqueteado con Bootstrap. 

