-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 19-11-2021 a las 14:40:56
-- Versión del servidor: 10.4.20-MariaDB
-- Versión de PHP: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `PD3`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `artistas`
--

CREATE TABLE `artistas` (
  `id` int(8) NOT NULL,
  `nombre` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `apellido` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `bio` text COLLATE utf8_spanish_ci NOT NULL,
  `foto` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `artistas`
--

INSERT INTO `artistas` (`id`, `nombre`, `apellido`, `bio`, `foto`) VALUES
(2, 'Walter ', 'Gropius', '<h1><strong>Walter Gropius</h1></strong> <p>Es un arquitecto alemán, que cuenta con un gran prestigio a nivel mundial. Es conocido por ser uno de los pioneros de la renovación arquitectónica del siglo XX y por el papel desempeñado en el ámbito de la enseñanza, especialmente, con la creación de La Bauhaus, escuela que siempre irá vinculada a su nombre.</p>\r\n\r\n<p>Aunque al hablar del Walter Gropius, siempre se haga del lado de la <strong>arquitectura</strong>, lo cierto es que, entrando en detalles, su nombre también aparecerá vinculado al urbanismo y al diseño. Ambas disciplinas irán de la mano de la arquitectura, convirtiéndose en el centro de su vida y, por lo tanto, de su profesión.</p>\r\n\r\n', 'img/walter.jpg'),
(3, 'Hannes', 'Meyer', '<h1><strong>Hans Meyer</h1></strong> \r\n<p>Es un arquitecto y urbanista suizo, fue el <strong>segundo director de la escuela de arte de la Bauhaus</strong> durante una efímera etapa de su carera, desde 1928 a 1930. Año y medio antes de que Gropius le nombrase su sucesor, le invitó a formar parte del taller de arquitectura dentro de la escuela.</p>\r\n\r\n<p>Meyer no concebía la arquitectura como una acción artística: bajo el lema <i>“las necesidades de las personas en lugar de las necesidades lujosas”</i>, transmitió en la escuela la idea de anteponer el caracter social de la arquitectura a la ornamentación.</p> \r\n\r\n<p>Su vida y obra se vieron fuertemente influenciadas por sus ideas políticas, dando lugar a numerosas polémicas, que terminaron ensombreciendo en cierta forma su trayectoria como docente y director de la Bauhaus.</p>', 'img/meyer.jpg'),
(4, 'Ludwig Mies', 'van der Rohe', '<h1><strong>Ludwig Mies van der Rohe</strong></h1>\r\n<p><strong>Arquitecto Ludwig Mies van der Rohe</strong>, Es otro de los arquitectos famosos de la Bauhaus, de la cual fue director. Su estilo arquitectónico emplea técnicas estructurales avanzadas, y aplica el clasicismo prusiano. Realizó diseños con acero y cristal.</p>\r\n<p>Fue decano de la escuela de arquitectura de Chicago, durante su exilio en Estados Unidos. Una de sus obras icónicas es el edificio Seagram en New York, considerado la máxima expresión del estilo internacional.</p>\r\n\r\n <p>En 1900 comenzó a trabajar en el taller de su padre, que era cantero, y en 1905 se trasladó a Berlín para colaborar en el estudio de Bruno Paul y, de 1908 a 1911, en el de P. Behrens, donde conoció a Walter Gropius y Le Corbusier, que son, junto con él mismo y el estadounidense, F. Ll. Wright, los mayores arquitectos del siglo XX.</p>\r\n<p>En sus comienzos se declino hacia la arquitectura neoclásica, pero un viaje a los Países Bajos en 1912 le llevó a cambiar sus intereses, a raíz del descubrimiento de la obra de H. P. Berlage. Tras el paréntesis de la Primera Guerra Mundial, se adhirió a diversos movimientos de vanguardia (Novembergruppe, De Stijl) y empezó a realizar proyectos revolucionarios, como el destinado a un edificio de oficinas de la Friedrichstrasse de Berlín, constituido por dos torres de veinte pisos unidas por un núcleo central para escaleras y ascensores.</p>', 'img/vander.jpg'),
(5, 'Vasíli', 'Kandinsky', '<h1><strong>Vasíli Kandinsky</strong></h1>\r\n<p>(Vasíli o Wassily Kandinski o Kandinsky; Moscú, Rusia, 1866 - Neuilly-sur-Seine, 1944) <strong>Pintor de origen ruso</strong> (nacionalizado alemán y posteriormente francés), destacado pionero y teórico del arte abstracto. </p>\r\n\r\n<p>Kandinsky compaginó sus estudios de derecho y economía con clases de dibujo y pintura. Al tiempo que se interesaba por la cultura primitiva y las manifestaciones artísticas populares rusas, muy especialmente por el arte propio de la región de Volodga, rico en ornamentos, también descubrió la obra de Rembrandt y Monet.</p>', 'img/kandisky.jpeg'),
(6, 'Paul', 'Klee', '<h1><strong>Paul Klee</strong></h1>\r\n<p>Pintor suizo, <strong>asociado al movimiento expresionista alemán Der Blaue Reiter</strong> y creador más tarde de una visión personal de los miedos y las fantasías del hombre del siglo XX. Nació en Münchenbuchsee (Suiza) en 1879, en el seno de una familia de músicos, y falleció en Locarno en 1940. </p>\r\n\r\n<p>La pasión por la música, que caracteriza su infancia, marcará profundamente su vida y su obra. Pronto se convierte en un poeta y músico bien preparado. Entre 1988 y 1901 estudia en Mónaco. Hace su primer viaje a Italia, donde le impresiona la tradición renacentista. Admira el simbolismo visionario de Blake y Goya, así como el de Ensor y Redon, cuyo trabajo había visto en París en 1905. Se establece en Berna en 1902.\r\nExpone dibujos satíricos en la Secession de Mónaco (1906), donde tiene ocasion de ver obras de Ensor, Cézanne, Van Gogh y Matisse. En ese mismo año participa en la Secession de Munich donde se familiariza con la pintura impresionista, bajo cuyo influjo empieza a trabajar a partir de la naturaleza.</p>', 'img/klee.jpg'),
(7, 'Herbert ', 'Bayer', '<h1>Herbert Bayer</h1>\r\n<p> fue <strong>maestro de tipografía en la Bauhaus</strong>, movimiento fundado por Walter Gropius que se desarrolló en Alemania entre 1919 y 1933. Además de Gropius, la Bauhaus contó con maestros de la talla de Paul Klee, Vassili Kandinsky, Marcel Breuer, Lyonel Feininger, Johannes Meyer ( Laszlo Moholy-Nagy.Bayer dejó la Bauhaus en 1928 y estableció su propio estudio en Berlín, trabajando como pintor, diseñador gráfico, comisario de exposiciones y fotógrafo.</p>\r\n\r\n<p>La obra de Bayer incluye más de 100 exposiciones de <strong>pintura, escultura, tapices y fotografías.</strong> Su obra se puede ver en museos, universidades, sedes de corporaciones y colecciones alrededor del mundo. Su última obra mayor, una escultura de 850 toneladas de peso y titulada Muro articulado, fue terminada el pasado mes de julio, en Denver (Colorado).</p>', 'img/bayer.jpg'),
(9, 'Johannes ', ' Itten', '<h1>Johannes Itten</h1>\r\n<p>Fue un pintor suizo, estuvo estrechamente vinculado a la escuela alemana conocida como Bauhaus, de la que fue uno de sus miembros fundadores.</p>\r\n\r\n<p>Comenzó sus estudios en 1904, e ingresó en un seminario sobre profesorado en Berna. Finalizados éstos, ejerció como profesor. Acorde con su gusto heterogéneo, se matriculó en cursos de matemáticas y ciencias naturales, los cuales ejercieron gran influencia cuando posteriormente fuese el encargado de dirigir el \"Vorkus\" o curso preparatorio de los estudios en la Bauhaus.</p>', 'img/itten.jpeg'),
(10, 'Láslo ', ' Moholy-Nagy', '<h1>László Moholy-Nagy</h1>\r\n\r\n<p>Fue un <strong>pintor y fotógrafo húngaro</strong>, László Moholy-Nagy nace en julio de 1895 en Bácsborsard. Con el estallido de la Primera Guerra Mundial, se alista en el ejército húngaro y abandona los estudios de Derecho. Durante la contienda, realiza sus primeras incursiones en las artes plásticas, con trabajos en tiza y tinta china.<p>\r\n\r\n<p>En 1920 conoce a la que sería su mujer, la fotógrafa Lucía Schulz. Junto a ella empieza a indagar en el mundo de la fotografía y a ser reconocido por ello. Un año después dirige un taller de metal en la Bauhaus, escuela que pasa a dirigir posteriormente. Su publicación Pintura, fotografía, film (1925) constituye el octavo volumen de los Libros de la Bauhaus.\r\n</p>\r\n<p>Como pintor y fotógrafo desarrolló un arte no figurativo y construyó sus obras a partir de elementos visuales: texturas, luz, color y equilibrio de las formas. Emigró a Chicago en 1937 y allí fundó la escuela New Bauhaus, que no llegó a prosperar.</p> \r\n\r\n<p>Murió en noviembre de 1946 en esta ciudad americana. En la actualidad es considerado como uno de los más destacados teóricos del arte y la fotografía de la historia.</p>', 'img/Nagy.jpg\r\n');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(8) NOT NULL,
  `nombre` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `apellido` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellido`, `email`, `usuario`, `password`) VALUES
(1, 'Luna', '', 'lunabectuchi1@gmail.com', 'Lunita123', 'a95238df9190e26ce56f7f95bc51d229'),
(5, 'Marcela', 'De La Llave', 'marceladelallave@marcela.com', 'Marcela', '202cb962ac59075b964b07152d234b70'),
(6, 'Catalina', 'Fernandez', 'cata@gmail.com', 'Catita', '202cb962ac59075b964b07152d234b70'),
(7, 'Jose', 'Mico', 'jose1@gmail.com', 'Jose', '202cb962ac59075b964b07152d234b70'),
(8, 'Cami', 'hola', 'cami@cami.com', 'cami', '202cb962ac59075b964b07152d234b70'),
(9, 'Marcela', 'de la llave', 'marceladelallave11@gmail.com', 'Marcela', '202cb962ac59075b964b07152d234b70'),
(10, 'luna', 'bectuch', 'lunita@gmail.com', 'luni', '202cb962ac59075b964b07152d234b70'),
(11, 'cami', 'de la llave', 'marceladelallave11@gmail.com', 'camila', '8c8a58fa97c205ff222de3685497742c'),
(12, 'Mica', 'Mica', '', 'Mica1', '202cb962ac59075b964b07152d234b70'),
(13, 'Araceli', 'Kim', '', 'Aracelii', 'fb1eaf2bd9f2a7013602be235c305e7a');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `artistas`
--
ALTER TABLE `artistas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `artistas`
--
ALTER TABLE `artistas`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
