<?php
session_start();

if(array_key_exists("logueado", $_SESSION)) {

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>BAUHAUS</title>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
<link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Didact+Gothic&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/all.min.css">
<script src="https://kit.fontawesome.com/fb5009540f.js" crossorigin="anonymous"></script>


</head>

<body class="index">
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.html">BAUHAUS</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="subpaginas/historia.html">HISTORIA</a>
         <a class="nav-link active" aria-current="page" href="subpaginas/Ramas.html">RAMAS</a>
          <a class="nav-link active" aria-current="page" href="subpaginas/museos.html">MUSEOS</a>
           <a class="nav-link active" aria-current="page" href="subpaginas/exponentes.html">EXPONENTES</a>
            <a class="nav-link active" aria-current="page" href="subpaginas/enargentina.html">EN ARGENTINA</a> 
            <a class="nav-link active" aria-current="page" href="subpaginas/newsletter.html">NEWSLETTER</a>
      
      </div>

    </div>   
<a href="form_login.php"><span style="font-size: 30px;">
  <span style="color: white;">
    <span style="padding: 15px">
  <i class="fas fa-user"></i>
  </span>
</span>
</span></a>
    <form action="resultados_buscar.php" method="post">
    <input type="search" name="buscar" placeholder="Buscar..." />
    <input type="submit" value="Enviar">
    </label>
    </form>
  </div>
</nav>
 <div class="contenedor-total">
 <h1 style="text-align: center;padding: 20px">Bienvenido! </h1>
 <img src="img/arqui1.jpg" style="width: 100%">
 <p style="font-size: 20px; padding-left: 10px">Desde acá vas a poder acceder a nueva información sobre la BAUHAUS</p>
 <p style="font-size: 17px; padding-left: 10px">No te preocupes, nadie puede ver tu información, solo vos!</p>
 <h2 style="padding-left: 10px"><a href="sesion3.php">Siguiente >>  </a></h2>
</div>
  <footer>
  
<p>Luna Bectuchi</p>
<p>Producción Digital III</p>


</footer>

<?php } else{
  header('Location: login.php');
}

?>

</body>
</html>

