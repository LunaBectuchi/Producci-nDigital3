
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
<link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Didact+Gothic&display=swap" rel="stylesheet">

    <title>BAUHAUS</title>
  </head>
 
  <body class="index">
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.html">BAUHAUS</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="subpaginas/historia.html">HISTORIA</a>
         <a class="nav-link active" aria-current="page" href="subpaginas/Ramas.html">RAMAS</a>
          <a class="nav-link active" aria-current="page" href="subpaginas/museos.html">MUSEOS</a>
           <a class="nav-link active" aria-current="page" href="subpaginas/exponentes.html">EXPONENTES</a>
            <a class="nav-link active" aria-current="page" href="subpaginas/enargentina.html">EN ARGENTINA</a> 
            <a class="nav-link active" aria-current="page" href="subpaginas/newsletter.html">NEWSLETTER</a>
      
      </div>
    </div>
    <form action="buscador/resultados_buscar.php" method="post">
    <label>Buscar Empleados
    <input type="search" name="buscar" placeholder="Buscar..." />
    <input type="submit" value="Enviar">
    </label>
    </form>
  </div>
</nav>
                                   
                                     <div class="contenedor-total">

<div class="bannerhistoria"><img src="img/resultados.png"></div>
 
 <section>

<?php
  include('conexion.php');

  $buscar = $_POST['buscar'];
  echo "Resultados: <em>".$buscar."</em><br>";

  $consulta = mysqli_query($conexion, "SELECT * FROM artistas WHERE nombre LIKE '%$buscar%' OR apellido LIKE '%$buscar%' ");
?>
<article style="width:80%;margin:0 auto;padding:10px">
  <p>Cantidad de Resultados: 
  <?php
    $nros=mysqli_num_rows($consulta);
    echo $nros;
  ?>
  </p>
    
  <?php
    while($resultados=mysqli_fetch_array($consulta)) {
  ?>
    <p>
    <?php 
      echo $resultados['nombre'] . " ";
      echo $resultados['apellido'] . " --> ";
      echo $resultados['bio'];
  ?>
    </p>
        <img src="<?php echo $resultados['foto'];?> ">
    <hr/>
    <?php
    }

    mysqli_free_result($consulta);
    mysqli_close($conexion);

  ?>
</article>
</section>                                     

 <footer>
  
<p>Luna Bectuchi</p>
<p>Producción Digital III</p>

</footer>
                                     </div>
                                                     

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script src="assets/dist/js/bootstrap.bundle.min.js"></script>
                                    
  </body>
</html>