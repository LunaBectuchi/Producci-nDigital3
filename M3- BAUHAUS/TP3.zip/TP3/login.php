<?php
session_start();

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
<link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Didact+Gothic&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/all.min.css">
<script src="https://kit.fontawesome.com/fb5009540f.js" crossorigin="anonymous"></script>


    <title>BAUHAUS</title>
  </head>
 
  <body class="index">
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.html">BAUHAUS</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="subpaginas/historia.html">HISTORIA</a>
         <a class="nav-link active" aria-current="page" href="subpaginas/Ramas.html">RAMAS</a>
          <a class="nav-link active" aria-current="page" href="subpaginas/museos.html">MUSEOS</a>
           <a class="nav-link active" aria-current="page" href="subpaginas/exponentes.html">EXPONENTES</a>
            <a class="nav-link active" aria-current="page" href="subpaginas/enargentina.html">EN ARGENTINA</a> 
            <a class="nav-link active" aria-current="page" href="subpaginas/newsletter.html">NEWSLETTER</a>
      
      </div>

    </div>   
<a href="form_registro.php"><span style="font-size: 30px;">
  <span style="color: white;">
    <span style="padding: 15px">
  <i class="fas fa-user"></i>
  </span>
</span>
</span></a>
    <form action="resultados_buscar.php" method="post">
    <input type="search" name="buscar" placeholder="Buscar..." />
    <input type="submit" value="Enviar">
    </label>
    </form>
  </div>
</nav>
                                   
                                     <div class="contenedor-total">

   
<?php
$usuario = $_POST['usuario'];
$password =md5($_POST['password']);

include("conexion.php");

$consulta = mysqli_query($conexion, "SELECT nombre, apellido, email FROM usuarios WHERE usuario='$usuario' AND password='$password'");

$resultado = mysqli_num_rows($consulta);

if($resultado!=0){
  $respuesta=mysqli_fetch_array($consulta);

$_SESSION["names"]=$respuesta['nombre'];  
$_SESSION['logueado']="ok";

header('Location:sesion2.php');

} 


else {
  
  echo "No es un usuario registrado";
  include ("form_registros.php");
  
}

?>

 <div class="bannerindex">
      
      <img src="img/logo.jpg">
    </div>      


 <footer>
  
<p>Luna Bectuchi</p>
<p>Producción Digital III</p>

</footer>
                                     </div>
                                                     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script src="assets/dist/js/bootstrap.bundle.min.js"></script>
  
</body>
</html>