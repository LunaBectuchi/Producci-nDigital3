
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
<link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Didact+Gothic&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/all.min.css">
<script src="https://kit.fontawesome.com/fb5009540f.js" crossorigin="anonymous"></script>


    <title>BAUHAUS</title>
  </head>
           
                                     <div class="contenedor-total">
                                        <section class="vh-100">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6 text-black">

        <div class="px-5 ms-xl-4">
           <div class="bannerindex">
      
      <img src="img/logo.jpg">
    </div>   
        </div>
        <div class="d-flex align-items-center h-custom-2 px-5 ms-xl-4 mt-5 pt-5 pt-xl-0 mt-xl-n5">

          <form class="registro" action="registro.php" method="post" style="width: 23rem;">

            <h3 class="fw-normal mb-3 pb-3" style="letter-spacing: 1px;">Registrate en nuestra página!</h3>

                      <p style="text-align: left;">¿Ya tenés usuario? <a href="form_login.php">Logueate!</a></p>

            <div class="form-outline mb-4">
             
              <input name="nombre" type="text" id="form2Example18" class="form-control form-control-lg" required  />
              <label class="form-label" for="form2Example18">Nombre</label>
            </div>

            <div class="form-outline mb-4">
              <input name="apellido" type="text" id="form2Example28" class="form-control form-control-lg" required />
              <label class="form-label" for="form2Example28">Apellido</label>
            </div>


                        <div class="form-outline mb-4">
              <input name="usuario" type="text" id="form2Example28" class="form-control form-control-lg" required/>
              <label class="form-label" for="form2Example28">Nombre de Usuario</label>
            </div>

              <div class="form-outline mb-4">
              <input name="password" type="password" id="form2Example28" class="form-control form-control-lg"  required= />
              <label class="form-label" for="form2Example28">Constraseña</label>
            </div>

            <div class="pt-1 mb-4">
              <button class="btn btn-info btn-lg btn-block" type="submit" value="login" style="background-color: blue;color: white
              ">Registrarse</button>
            </div>
          </form>
        </div>
      </div>

      <div class="col-sm-6 px-0 d-none d-sm-block">
        <img src="img/secciondos.jpeg" alt="Login image" class="w-100 vh-100" style="object-fit: cover; object-position: left;">
      </div>
    </div>
  </div>
</section>
 </div>
                                
                                                     

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script src="assets/dist/js/bootstrap.bundle.min.js"></script>
                                    
  </body>
</html>