<?php
$conexion=mysqli_connect("localhost","root","", "pd3");
?>